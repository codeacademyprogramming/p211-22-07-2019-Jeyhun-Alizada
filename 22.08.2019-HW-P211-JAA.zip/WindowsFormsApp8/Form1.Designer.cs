﻿using System;

namespace WindowsFormsApp8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cmbBrends = new System.Windows.Forms.ComboBox();
            this.cmbModels = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBrend = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.btnAddBrend = new System.Windows.Forms.Button();
            this.btnAddModel = new System.Windows.Forms.Button();
            this.btnDelBrend = new System.Windows.Forms.Button();
            this.btnUpdBrend = new System.Windows.Forms.Button();
            this.btnUpdModel = new System.Windows.Forms.Button();
            this.btnDelModel = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBrendId = new System.Windows.Forms.TextBox();
            this.txtUpdBrend = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUpdModel = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 20);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Brends";
            // 
            // cmbBrends
            // 
            this.cmbBrends.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBrends.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBrends.FormattingEnabled = true;
            this.cmbBrends.Location = new System.Drawing.Point(32, 77);
            this.cmbBrends.Margin = new System.Windows.Forms.Padding(4);
            this.cmbBrends.Name = "cmbBrends";
            this.cmbBrends.Size = new System.Drawing.Size(238, 23);
            this.cmbBrends.TabIndex = 1;
            this.cmbBrends.SelectedIndexChanged += new System.EventHandler(this.CmbBrends_SelectedIndexChanged);
            // 
            // cmbModels
            // 
            this.cmbModels.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbModels.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbModels.FormattingEnabled = true;
            this.cmbModels.Location = new System.Drawing.Point(456, 77);
            this.cmbModels.Margin = new System.Windows.Forms.Padding(4);
            this.cmbModels.Name = "cmbModels";
            this.cmbModels.Size = new System.Drawing.Size(238, 23);
            this.cmbModels.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(453, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Models";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 146);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Brend name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(453, 146);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Model name";
            // 
            // txtBrend
            // 
            this.txtBrend.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBrend.Location = new System.Drawing.Point(32, 208);
            this.txtBrend.Margin = new System.Windows.Forms.Padding(4);
            this.txtBrend.Name = "txtBrend";
            this.txtBrend.Size = new System.Drawing.Size(135, 22);
            this.txtBrend.TabIndex = 6;
            // 
            // txtModel
            // 
            this.txtModel.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModel.Location = new System.Drawing.Point(456, 208);
            this.txtModel.Margin = new System.Windows.Forms.Padding(4);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(149, 22);
            this.txtModel.TabIndex = 7;
            // 
            // btnAddBrend
            // 
            this.btnAddBrend.Location = new System.Drawing.Point(32, 298);
            this.btnAddBrend.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddBrend.Name = "btnAddBrend";
            this.btnAddBrend.Size = new System.Drawing.Size(240, 28);
            this.btnAddBrend.TabIndex = 8;
            this.btnAddBrend.Text = "Add Brend";
            this.btnAddBrend.UseVisualStyleBackColor = true;
            this.btnAddBrend.Click += new System.EventHandler(this.BtnAddBrend_Click);
            // 
            // btnAddModel
            // 
            this.btnAddModel.Location = new System.Drawing.Point(456, 298);
            this.btnAddModel.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddModel.Name = "btnAddModel";
            this.btnAddModel.Size = new System.Drawing.Size(240, 28);
            this.btnAddModel.TabIndex = 9;
            this.btnAddModel.Text = "Add Model";
            this.btnAddModel.UseVisualStyleBackColor = true;
            this.btnAddModel.Click += new System.EventHandler(this.BtnAddModel_Click);
            // 
            // btnDelBrend
            // 
            this.btnDelBrend.Location = new System.Drawing.Point(32, 449);
            this.btnDelBrend.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelBrend.Name = "btnDelBrend";
            this.btnDelBrend.Size = new System.Drawing.Size(240, 28);
            this.btnDelBrend.TabIndex = 10;
            this.btnDelBrend.Text = "Delete Brend";
            this.btnDelBrend.UseVisualStyleBackColor = true;
            this.btnDelBrend.Click += new System.EventHandler(this.BtnDelBrend_Click);
            // 
            // btnUpdBrend
            // 
            this.btnUpdBrend.Location = new System.Drawing.Point(32, 369);
            this.btnUpdBrend.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdBrend.Name = "btnUpdBrend";
            this.btnUpdBrend.Size = new System.Drawing.Size(240, 28);
            this.btnUpdBrend.TabIndex = 11;
            this.btnUpdBrend.Text = "Update Brend";
            this.btnUpdBrend.UseVisualStyleBackColor = true;
            this.btnUpdBrend.Click += new System.EventHandler(this.BtnUpdBrend_Click_1);
            // 
            // btnUpdModel
            // 
            this.btnUpdModel.Location = new System.Drawing.Point(456, 369);
            this.btnUpdModel.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdModel.Name = "btnUpdModel";
            this.btnUpdModel.Size = new System.Drawing.Size(240, 28);
            this.btnUpdModel.TabIndex = 12;
            this.btnUpdModel.Text = "Update Model";
            this.btnUpdModel.UseVisualStyleBackColor = true;
            this.btnUpdModel.Click += new System.EventHandler(this.BtnUpdModel_Click);
            // 
            // btnDelModel
            // 
            this.btnDelModel.Location = new System.Drawing.Point(456, 449);
            this.btnDelModel.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelModel.Name = "btnDelModel";
            this.btnDelModel.Size = new System.Drawing.Size(240, 28);
            this.btnDelModel.TabIndex = 13;
            this.btnDelModel.Text = "Delete Model";
            this.btnDelModel.UseVisualStyleBackColor = true;
            this.btnDelModel.Click += new System.EventHandler(this.BtnDelModel_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(621, 146);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "Brend Id";
            // 
            // txtBrendId
            // 
            this.txtBrendId.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBrendId.Location = new System.Drawing.Point(624, 208);
            this.txtBrendId.Margin = new System.Windows.Forms.Padding(4);
            this.txtBrendId.Name = "txtBrendId";
            this.txtBrendId.Size = new System.Drawing.Size(58, 22);
            this.txtBrendId.TabIndex = 15;
            // 
            // txtUpdBrend
            // 
            this.txtUpdBrend.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdBrend.Location = new System.Drawing.Point(135, 249);
            this.txtUpdBrend.Margin = new System.Windows.Forms.Padding(4);
            this.txtUpdBrend.Name = "txtUpdBrend";
            this.txtUpdBrend.Size = new System.Drawing.Size(135, 22);
            this.txtUpdBrend.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(29, 255);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "New name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(453, 261);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 16);
            this.label7.TabIndex = 19;
            this.label7.Text = "New name";
            // 
            // txtUpdModel
            // 
            this.txtUpdModel.Font = new System.Drawing.Font("Britannic Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUpdModel.Location = new System.Drawing.Point(559, 255);
            this.txtUpdModel.Margin = new System.Windows.Forms.Padding(4);
            this.txtUpdModel.Name = "txtUpdModel";
            this.txtUpdModel.Size = new System.Drawing.Size(135, 22);
            this.txtUpdModel.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(727, 506);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtUpdModel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtUpdBrend);
            this.Controls.Add(this.txtBrendId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnDelModel);
            this.Controls.Add(this.btnUpdModel);
            this.Controls.Add(this.btnUpdBrend);
            this.Controls.Add(this.btnDelBrend);
            this.Controls.Add(this.btnAddModel);
            this.Controls.Add(this.btnAddBrend);
            this.Controls.Add(this.txtModel);
            this.Controls.Add(this.txtBrend);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbModels);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbBrends);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Britannic Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void BtnUpdBrend_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbBrends;
        private System.Windows.Forms.ComboBox cmbModels;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBrend;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.Button btnAddBrend;
        private System.Windows.Forms.Button btnAddModel;
        private System.Windows.Forms.Button btnDelBrend;
        private System.Windows.Forms.Button btnUpdBrend;
        private System.Windows.Forms.Button btnUpdModel;
        private System.Windows.Forms.Button btnDelModel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBrendId;
        private System.Windows.Forms.TextBox txtUpdBrend;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtUpdModel;
    }
}

