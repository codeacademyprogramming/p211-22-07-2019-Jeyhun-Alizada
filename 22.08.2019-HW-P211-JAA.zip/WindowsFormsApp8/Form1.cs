﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
       private readonly string connectionString = ConfigurationManager.ConnectionStrings["default"].ConnectionString;
       public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FillCmbBrends();
        }
        private void FillCmbBrends()
        {
            cmbBrends.Items.Clear();
            string connectionString = @"Server = DESKTOP-RMF8ROT\SQLEXPRESS; Database = WinFormCars; Integrated Security = sspi;";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string commandtext = "select Name from Brends";
                using (SqlCommand command = new SqlCommand(commandtext, conn))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cmbBrends.Items.Add(reader.GetString(0));
                        }
                    }
                }
            }
        }

        private void CmbBrends_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbModels.Items.Clear();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string commandtext = $"select Models.Name from Models join Brends on Models.BrendId = Brends.Id where Brends.Name = '{cmbBrends.Text}'";
                using (SqlCommand mycommand = new SqlCommand(commandtext, conn))
                {
                    using (SqlDataReader reader = mycommand.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                cmbModels.Items.Add(reader.GetString(0));
                            }
                        }
                        else
                        {
                            MessageBox.Show($"{cmbBrends.Text} has no  models in our database.");
                        }
                    }
                }
            }
        }

        private void BtnAddBrend_Click(object sender, EventArgs e)
        {

            string brend = txtBrend.Text.Trim();

            if (brend != string.Empty)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string commandText = $"select * from  Brends where Name = '{brend}'";

                    using (SqlCommand command = new SqlCommand(commandText, conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                MessageBox.Show("This Brend already exists!!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        command.CommandText = $"insert into Brends values('{brend}')";
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected >= 1)
                        {
                            MessageBox.Show($"{brend} was successfully added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtBrend.Text = "";
                            FillCmbBrends();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Input any true brend name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnAddModel_Click(object sender, EventArgs e)
        {
            string model = txtModel.Text.Trim();
            string brendId = txtBrendId.Text.Trim();
            if (model != string.Empty)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string commandText = $"select * from  Models where Name = '{model}'";

                    using (SqlCommand command = new SqlCommand(commandText, conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                MessageBox.Show("This model already exists!!!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        command.CommandText = $"insert into Models values('{model}',{brendId})";
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected >= 1)
                        {
                            MessageBox.Show($"{model} was successfully added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtModel.Text = "";
                            txtBrendId.Text = "";
                            FillCmbBrends();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Input any true brend name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUpdBrend_Click_1(object sender, EventArgs e)
        {
            string newName = txtUpdBrend.Text.Trim();
            string brend = txtBrend.Text.Trim();
            if (brend != string.Empty)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string commandText = $"select * from  Brends where Name = '{brend}'";

                    using (SqlCommand command = new SqlCommand(commandText, conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                MessageBox.Show("Input true brend name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        command.CommandText = $"update Brends set Name = '{newName}' where Name = '{brend}'";
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected >= 1)
                        {
                            MessageBox.Show($"{brend} was successfully updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtBrend.Text = "";
                            txtUpdBrend.Text = "";
                            FillCmbBrends();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Input any true brend name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDelBrend_Click(object sender, EventArgs e)
        {
            string brend = txtBrend.Text.Trim();
            if (brend != string.Empty)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string commandText = $"select * from  Brends where Name = '{brend}'";

                    using (SqlCommand command = new SqlCommand(commandText, conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                MessageBox.Show("Input true brend name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        command.CommandText = $"delete Brends where Name = '{brend}'";
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected >= 1)
                        {
                            MessageBox.Show($"{brend} was successfully deleted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtBrend.Text = "";
                            txtUpdBrend.Text = "";
                            FillCmbBrends();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Input any true brend name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUpdModel_Click(object sender, EventArgs e)
        {
            string newName = txtUpdModel.Text.Trim();
            string model = txtModel.Text.Trim();
            if (model != string.Empty)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string commandText = $"select * from  Models where Name = '{model}'";

                    using (SqlCommand command = new SqlCommand(commandText, conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                MessageBox.Show("Input true model name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        command.CommandText = $"update Models set Name = '{newName}' where Name = '{model}'";
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected >= 1)
                        {
                            MessageBox.Show($"{model} was successfully updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtModel.Text = "";
                            txtUpdModel.Text = "";
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Input any true brend name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDelModel_Click(object sender, EventArgs e)
        {
            string model = txtModel.Text.Trim();
            if (model != string.Empty)
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string commandText = $"select * from  Models where Name = '{model}'";

                    using (SqlCommand command = new SqlCommand(commandText, conn))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (!reader.HasRows)
                            {
                                MessageBox.Show("Input true model name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        command.CommandText = $"delete Models where Name = '{model}'";
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected >= 1)
                        {
                            MessageBox.Show($"{model} was successfully deleted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtModel.Text = "";
                            txtUpdModel.Text = "";
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Input any true brend name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}